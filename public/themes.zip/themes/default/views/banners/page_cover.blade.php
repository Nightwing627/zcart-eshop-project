<section class="brand-banner-img-wrapper">
	<div class="banner banner-o-hid" style="background-color: #333; background-image:url( {{ get_cover_img_src($page, 'page') }} );">
		<div class="banner-caption">
			<h5 class="banner-title">{{ $page->title }}</h5>
			{{-- <p class="banner-desc">{{ $page->description }}</p> --}}
		</div>
	</div>
</section>