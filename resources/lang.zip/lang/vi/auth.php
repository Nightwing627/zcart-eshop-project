<?php 
return array (
  'failed' => 'Những thông tin không phù hợp với hồ sơ của chúng tôi.',
  'throttle' => 'Quá nhiều lần thử đăng nhập. Vui lòng thử lại sau :seconds giây.',
  'verification_link_sent' => 'Các liên kết xác minh đã gửi! Vui lòng kiểm tra email của bạn và xác minh tài khoản của bạn.',
  'verification_failed' => 'Liên kết này không hợp lệ hoặc hết hạn.',
  'verification_successful' => 'Tài khoản của bạn đã được xác minh thành công!',
  'resend_verification_link' => 'Gửi lại liên kết xác minh',
);