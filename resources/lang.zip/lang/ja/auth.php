<?php 
return array (
  'failed' => 'これらの資格情報は記録と一致しません。',
  'throttle' => 'ログイン試行が多すぎます。 :seconds秒後にもう一度お試しください。',
  'verification_link_sent' => '確認リンクが送信されました！メールを確認し、アカウントを確認してください。',
  'verification_failed' => 'このリンクは無効または期限切れです。',
  'verification_successful' => 'アカウントが正常に確認されました！',
  'resend_verification_link' => '確認リンクを再送信',
);