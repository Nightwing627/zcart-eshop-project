<?php 
return array (
  'failed' => 'Deze gegevens komen niet overeen met onze gegevens.',
  'throttle' => 'Te veel inlogpogingen. Probeer het over :seconds seconden opnieuw.',
  'verification_link_sent' => 'De verificatielink verzonden! Controleer uw e-mail en verifieer uw account.',
  'verification_failed' => 'Deze link is niet geldig of verlopen.',
  'verification_successful' => 'Uw account is succesvol geverifieerd!',
  'resend_verification_link' => 'Verificatielink opnieuw verzenden',
);