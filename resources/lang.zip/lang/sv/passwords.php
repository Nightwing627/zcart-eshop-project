<?php 
return array (
  'password' => 'Lösenord måste vara minst sex tecken och matcha bekräftelsen.',
  'reset' => 'Ditt lösenord har blivit återställt!',
  'sent' => 'Vi har e-postat din länk till återställning av lösenord',
  'token' => 'Token för återställning av lösenord är ogiltigt.',
  'user' => 'Vi kan inte hitta en användare med den e-postadressen.',
);