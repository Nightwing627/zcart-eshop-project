<?php 
return array (
  'failed' => 'Dessa referenser matchar inte våra poster.',
  'throttle' => 'För många inloggningsförsök. Försök igen om :seconds sekunder.',
  'verification_link_sent' => 'Verifieringslänken har skickats! Kontrollera din e-post och verifiera ditt konto.',
  'verification_failed' => 'Den här länken är inte giltig eller har löpt ut.',
  'verification_successful' => 'Ditt konto har verifierats!',
  'resend_verification_link' => 'Skicka verifieringslänk igen',
);