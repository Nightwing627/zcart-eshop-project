<?php 
return array (
  'failed' => 'Kredensial ini tidak cocok dengan catatan kami.',
  'throttle' => 'Terlalu banyak upaya masuk. Silakan coba lagi dalam :seconds detik.',
  'verification_link_sent' => 'Tautan verifikasi terkirim! Silakan periksa email Anda dan verifikasi akun Anda.',
  'verification_failed' => 'Tautan ini tidak valid atau kedaluwarsa.',
  'verification_successful' => 'Akun Anda telah berhasil diverifikasi!',
  'resend_verification_link' => 'Kirim ulang tautan verifikasi',
);