<?php 
return array (
  'failed' => 'Bu kimlik bilgileri kayıtlarımızla eşleşmiyor.',
  'throttle' => 'Çok fazla giriş yapma denemesi var. Lütfen :seconds saniye içinde tekrar deneyin.',
  'verification_link_sent' => 'Doğrulama bağlantısı gönderildi! Lütfen e-postanızı kontrol edin ve hesabınızı doğrulayın.',
  'verification_failed' => 'Bu link geçerli değil veya süresi dolmuş.',
  'verification_successful' => 'Hesabınız başarıyla doğrulandı!',
  'resend_verification_link' => 'Doğrulama bağlantısını tekrar gönder',
);