<?php 
return array (
  'failed' => 'Ces informations d\'identification ne correspondent pas à nos enregistrements.',
  'throttle' => 'Trop de tentatives de connexion. Veuillez réessayer dans :seconds secondes.',
  'verification_link_sent' => 'Le lien de vérification envoyé! Veuillez vérifier votre email et vérifier votre compte.',
  'verification_failed' => 'Ce lien n\'est pas valide ou a expiré.',
  'verification_successful' => 'Votre compte a été vérifié avec succès!',
  'resend_verification_link' => 'Renvoyer le lien de vérification',
);