<?php 
return array (
  'failed' => 'Estas credenciales no coinciden con nuestros registros.',
  'throttle' => 'Demasiados intentos de inicio de sesión. Por favor intente nuevamente en :seconds segundos.',
  'verification_link_sent' => 'El enlace de verificación enviado! Por favor revise su correo electrónico y verifique su cuenta.',
  'verification_failed' => 'Este enlace no es válido o caducó.',
  'verification_successful' => 'Su cuenta ha sido verificada con éxito!',
  'resend_verification_link' => 'Reenviar enlace de verificación',
);