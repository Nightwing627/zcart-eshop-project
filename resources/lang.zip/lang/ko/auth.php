<?php 
return array (
  'failed' => '이 자격 증명은 우리의 기록과 일치하지 않습니다.',
  'throttle' => '로그인 시도가 너무 많습니다. :seconds 초 후에 다시 시도하십시오.',
  'verification_link_sent' => '확인 링크가 전송되었습니다! 이메일을 확인하고 계정을 확인하십시오.',
  'verification_failed' => '이 링크는 유효하지 않거나 만료되었습니다.',
  'verification_successful' => '귀하의 계정이 성공적으로 확인되었습니다!',
  'resend_verification_link' => '재전송 확인 링크',
);