<?php 
return array (
  'failed' => 'Queste credenziali non corrispondono ai nostri record.',
  'throttle' => 'Troppi tentativi di accesso. Riprova tra :seconds secondi.',
  'verification_link_sent' => 'Il link di verifica inviato! Controlla la tua e-mail e verifica il tuo account.',
  'verification_failed' => 'Questo link non è valido o scaduto.',
  'verification_successful' => 'Il tuo account è stato verificato con successo!',
  'resend_verification_link' => 'Rinvia collegamento di verifica',
);