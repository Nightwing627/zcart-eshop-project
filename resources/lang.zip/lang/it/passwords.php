<?php 
return array (
  'password' => 'Le password devono contenere almeno sei caratteri e corrispondere alla conferma.',
  'reset' => 'La tua password è stata resettata!',
  'sent' => 'Abbiamo inviato il tuo link per reimpostare la password via e-mail!',
  'token' => 'Questo token di reimpostazione della password non è valido.',
  'user' => 'Non è possibile trovare un utente con quell\'indirizzo e-mail.',
);