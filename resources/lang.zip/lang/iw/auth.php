<?php 
return array (
  'failed' => 'תעודות אלה אינן תואמות את הרשומות שלנו.',
  'throttle' => 'יותר מדי ניסיונות כניסה. אנא נסה שוב תוך שניות :seconds.',
  'verification_link_sent' => 'קישור האימות נשלח! אנא בדוק את הדוא"ל שלך ואמת את חשבונך.',
  'verification_failed' => 'קישור זה אינו תקף או פג תוקפו.',
  'verification_successful' => 'חשבונך אומת בהצלחה!',
  'resend_verification_link' => 'שלח שוב את קישור האימות',
);