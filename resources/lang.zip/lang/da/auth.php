<?php 
return array (
  'failed' => 'Disse legitimationsoplysninger stemmer ikke overens med vores poster.',
  'throttle' => 'For mange loginforsøg. Prøv igen om :seconds sekunder.',
  'verification_link_sent' => 'Bekræftelseslinket blev sendt! Kontroller din e-mail og bekræft din konto.',
  'verification_failed' => 'Dette link er ikke gyldigt eller udløbet.',
  'verification_successful' => 'Din konto er bekræftet!',
  'resend_verification_link' => 'Send bekræftelseslink igen',
);