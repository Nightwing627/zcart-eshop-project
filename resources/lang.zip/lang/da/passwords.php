<?php 
return array (
  'password' => 'Adgangskoder skal være mindst seks tegn og svare til bekræftelsen.',
  'reset' => 'Din adgangskode er nulstillet!',
  'sent' => 'Vi har sendt dit link til nulstilling af adgangskode via e-mail!',
  'token' => 'Denne kode til nulstilling af adgangskode er ugyldig.',
  'user' => 'Vi kan ikke finde en bruger med den e-mail-adresse.',
);