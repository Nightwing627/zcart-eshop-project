<?php 
return array (
  'failed' => 'Disse opplysningene samsvarer ikke med postene våre.',
  'throttle' => 'For mange påloggingsforsøk. Vennligst prøv igjen om 1 sekund.',
  'verification_link_sent' => 'Bekreftelseslenken ble sendt! Vennligst sjekk e-posten din og bekreft kontoen din.',
  'verification_failed' => 'Denne lenken er ikke gyldig eller utløpt.',
  'verification_successful' => 'Kontoen din er bekreftet!',
  'resend_verification_link' => 'Send bekreftelseskoblingen på nytt',
);