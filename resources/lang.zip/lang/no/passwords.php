<?php 
return array (
  'password' => 'Passord må være minst seks tegn og samsvarer med bekreftelsen.',
  'reset' => 'Passordet ditt har blitt tilbakestilt!',
  'sent' => 'Vi har sendt e-postadressen din til tilbakestilling av passord!',
  'token' => 'Tokenet for tilbakestilling av passord er ugyldig.',
  'user' => 'Vi kan ikke finne en bruker med den e-postadressen.',
);