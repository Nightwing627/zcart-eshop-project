<?php 
return array (
  'failed' => 'Diese Anmeldeinformationen stimmen nicht mit unseren Aufzeichnungen überein.',
  'throttle' => 'Zu viele Anmeldeversuche. Bitte versuchen Sie es in :seconds Sekunden erneut.',
  'verification_link_sent' => 'Der Bestätigungslink wurde gesendet! Bitte überprüfen Sie Ihre E-Mails und verifizieren Sie Ihr Konto.',
  'verification_failed' => 'Dieser Link ist ungültig oder abgelaufen.',
  'verification_successful' => 'Ihr Account wurde erfolgreich verifiziert!',
  'resend_verification_link' => 'Bestätigungslink erneut senden',
);